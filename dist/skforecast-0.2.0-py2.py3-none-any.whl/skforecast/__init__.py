name = "skforecast"
__version__ = "0.2.0"
